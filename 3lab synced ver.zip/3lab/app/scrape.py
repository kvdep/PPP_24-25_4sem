import os
import fnmatch

def find_celery_folders(root_dir):
    """Находит все папки, заканчивающиеся на '_celery'"""
    celery_folders = []
    for root, dirs, files in os.walk(root_dir):
        for dir_name in dirs:
            if dir_name.endswith('_celery'):
                celery_folders.append(os.path.join(root, dir_name))
    return celery_folders

def get_code_files(folder):
    """Возвращает список всех файлов с кодом в папке и подпапках"""
    code_extensions = [
        '.py',  # Python
        '.js',   # JavaScript
        '.html', # HTML
        '.css',  # CSS
        '.json', # JSON
        '.sh',   # Shell scripts
        '.yml', '.yaml', # YAML
        '.txt', # Text files
        # добавьте другие нужные расширения
    ]
    
    code_files = []
    for root, dirs, files in os.walk(folder):
        for file in files:
            if any(file.endswith(ext) for ext in code_extensions):
                code_files.append(os.path.join(root, file))
    return code_files

def combine_code_to_file(folders, output_file='combined_code.txt'):
    """Объединяет код из всех файлов в один"""
    with open(output_file, 'w', encoding='utf-8') as outfile:
        for folder in folders:
            outfile.write(f"\n\n=== Folder: {folder} ===\n\n")
            code_files = get_code_files(folder)
            
            for code_file in code_files:
                try:
                    with open(code_file, 'r', encoding='utf-8') as infile:
                        outfile.write(f"\n--- File: {code_file} ---\n\n")
                        outfile.write(infile.read())
                        outfile.write('\n')
                except UnicodeDecodeError:
                    try:
                        with open(code_file, 'r', encoding='latin-1') as infile:
                            outfile.write(f"\n--- File: {code_file} ---\n\n")
                            outfile.write(infile.read())
                            outfile.write('\n')
                    except Exception as e:
                        outfile.write(f"\n!!! Could not read {code_file}: {str(e)} !!!\n")
                except Exception as e:
                    outfile.write(f"\n!!! Could not read {code_file}: {str(e)} !!!\n")

if __name__ == "__main__":
    # Начинаем поиск с текущей директории
    start_dir = os.getcwd()
    
    # Ищем все папки _celery
    celery_folders = find_celery_folders(start_dir)
    
    if not celery_folders:
        print("No folders ending with '_celery' found.")
    else:
        print(f"Found {len(celery_folders)} _celery folders:")
        for folder in celery_folders:
            print(f" - {folder}")
        
        # Объединяем код в один файл
        combine_code_to_file(celery_folders)
        print("\nAll code has been combined into 'combined_code.txt'")