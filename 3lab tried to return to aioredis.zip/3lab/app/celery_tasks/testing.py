import json
import redis
import redis.asyncio as aioredis
import asyncio



#from app.websocket.manager import manager

#redis_client = redis.Redis(host='redis', port=6379, db=0)
redis_client = redis.Redis(host='3lab-redis-1', port=6379, db=0)

'''
self.redis.publish("celery_progress", json.dumps({
            "type": "test",
            "message": "Redis test message"
        }))
'''

redis_client.publish('celery_progress',json.dumps({'testing':'testing'}))